package com.airbnb.booking.dto.request;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class AvailabilityRequest {

    @NotNull(message = "Available from date is required")
    @FutureOrPresent(message = "Available from date must be today or in the future")
    private LocalDate availableFrom;

    @NotNull(message = "Available to date is required")
    @FutureOrPresent(message = "Available to date must be today or in the future")
    private LocalDate availableTo;
}

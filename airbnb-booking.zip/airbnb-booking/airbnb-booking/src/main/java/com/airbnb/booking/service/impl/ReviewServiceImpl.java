package com.airbnb.booking.service.impl;

import com.airbnb.booking.dto.request.ReviewRequest;
import com.airbnb.booking.dto.response.ReviewResponse;
import com.airbnb.booking.entity.Property;
import com.airbnb.booking.entity.Review;
import com.airbnb.booking.entity.User;
import com.airbnb.booking.enums.UserRole;
import com.airbnb.booking.exception.ResourceNotFoundException;
import com.airbnb.booking.exception.UnauthorizedException;
import com.airbnb.booking.repository.BookingRepository;
import com.airbnb.booking.repository.PropertyRepository;
import com.airbnb.booking.repository.ReviewRepository;
import com.airbnb.booking.repository.UserRepository;
import com.airbnb.booking.service.ReviewService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImpl implements ReviewService {

    private static final Logger log = LoggerFactory.getLogger(ReviewServiceImpl.class);

    private final ReviewRepository reviewRepository;
    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;

    public ReviewServiceImpl(ReviewRepository reviewRepository,
                             PropertyRepository propertyRepository,
                             UserRepository userRepository,
                             BookingRepository bookingRepository) {
        this.reviewRepository = reviewRepository;
        this.propertyRepository = propertyRepository;
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
    }

    @Override
    @Transactional
    public ReviewResponse addReview(ReviewRequest request, String guestEmail) {
        User guest = userRepository.findByEmail(guestEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + guestEmail));

        if (guest.getRole() != UserRole.GUEST) {
            throw new UnauthorizedException("Only guests can leave reviews");
        }

        Property property = propertyRepository.findById(request.getPropertyId())
                .orElseThrow(() -> new ResourceNotFoundException("Property", request.getPropertyId()));

        // Guest must have a completed stay to leave a review
        boolean hasCompleted = bookingRepository.hasCompletedBooking(property.getId(), guest.getId());
        if (!hasCompleted) {
            throw new UnauthorizedException("You can only review a property after a completed stay");
        }

        // One review per guest per property
        if (reviewRepository.existsByPropertyIdAndGuestId(property.getId(), guest.getId())) {
            throw new IllegalArgumentException("You have already reviewed this property");
        }

        Review review = new Review();
        review.setProperty(property);
        review.setGuest(guest);
        review.setRating(request.getRating());
        review.setComment(request.getComment());

        Review saved = reviewRepository.save(review);
        log.info("Review added for property: {} by guest: {}", property.getId(), guestEmail);
        return ReviewResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReviewResponse> getPropertyReviews(Long propertyId) {
        propertyRepository.findById(propertyId)
                .orElseThrow(() -> new ResourceNotFoundException("Property", propertyId));
        return reviewRepository.findByPropertyId(propertyId)
                .stream().map(ReviewResponse::from).collect(Collectors.toList());
    }
}

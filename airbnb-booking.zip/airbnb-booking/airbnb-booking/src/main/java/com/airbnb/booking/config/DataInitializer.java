package com.airbnb.booking.config;

import com.airbnb.booking.entity.*;
import com.airbnb.booking.enums.BookingStatus;
import com.airbnb.booking.enums.UserRole;
import com.airbnb.booking.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final PropertyRepository propertyRepository;
    private final PropertyAvailabilityRepository availabilityRepository;
    private final BookingRepository bookingRepository;
    private final ReviewRepository reviewRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           PropertyRepository propertyRepository,
                           PropertyAvailabilityRepository availabilityRepository,
                           BookingRepository bookingRepository,
                           ReviewRepository reviewRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.propertyRepository = propertyRepository;
        this.availabilityRepository = availabilityRepository;
        this.bookingRepository = bookingRepository;
        this.reviewRepository = reviewRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        log.info("===== Seeding demo data =====");

        // ── Users ─────────────────────────────────────────────────────────────
        User host1 = createUser("Rahul Sharma",  "host1@demo.com", "password123", UserRole.HOST);
        User host2 = createUser("Priya Patel",   "host2@demo.com", "password123", UserRole.HOST);
        User guest1 = createUser("Amit Kumar",   "guest1@demo.com", "password123", UserRole.GUEST);
        User guest2 = createUser("Sneha Reddy",  "guest2@demo.com", "password123", UserRole.GUEST);

        // ── Properties ────────────────────────────────────────────────────────
        Property p1 = createProperty("Cozy Studio in Hyderabad", "Modern studio in HITEC City with great city views",
                "Hyderabad", new BigDecimal("2500.00"), host1);
        Property p2 = createProperty("Luxury Villa in Goa",    "Private villa with pool and beach access",
                "Goa",        new BigDecimal("8500.00"), host1);
        Property p3 = createProperty("Apartment in Bangalore", "2BHK in Indiranagar, close to metro",
                "Bangalore",  new BigDecimal("3500.00"), host2);
        Property p4 = createProperty("Heritage Haveli in Jaipur", "Stunning heritage property in the old city",
                "Jaipur",     new BigDecimal("4500.00"), host2);

        // ── Availability ──────────────────────────────────────────────────────
        addAvailability(p1, LocalDate.now(),                   LocalDate.now().plusMonths(6));
        addAvailability(p2, LocalDate.now(),                   LocalDate.now().plusMonths(6));
        addAvailability(p3, LocalDate.now(),                   LocalDate.now().plusMonths(6));
        addAvailability(p4, LocalDate.now(),                   LocalDate.now().plusMonths(6));

        // ── Past completed bookings (for demo reviews) ────────────────────────
        Booking b1 = createBooking(p1, guest1,
                LocalDate.now().minusDays(30), LocalDate.now().minusDays(27),
                new BigDecimal("7500.00"), BookingStatus.COMPLETED);
        Booking b2 = createBooking(p3, guest2,
                LocalDate.now().minusDays(20), LocalDate.now().minusDays(17),
                new BigDecimal("10500.00"), BookingStatus.COMPLETED);

        // ── Future confirmed booking ──────────────────────────────────────────
        createBooking(p2, guest1,
                LocalDate.now().plusDays(10), LocalDate.now().plusDays(14),
                new BigDecimal("34000.00"), BookingStatus.CONFIRMED);

        // ── Reviews (only after completed stay) ───────────────────────────────
        createReview(p1, guest1, 5, "Absolutely loved it! Very clean and central location.");
        createReview(p3, guest2, 4, "Great apartment, will definitely come back.");

        log.info("===== Demo data seeded =====");
        log.info("Login credentials – HOST:  host1@demo.com  / password123");
        log.info("Login credentials – HOST:  host2@demo.com  / password123");
        log.info("Login credentials – GUEST: guest1@demo.com / password123");
        log.info("Login credentials – GUEST: guest2@demo.com / password123");
        log.info("Swagger UI  → http://localhost:8080/swagger-ui.html");
        log.info("H2 Console  → http://localhost:8080/h2-console");
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private User createUser(String name, String email, String rawPassword, UserRole role) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPassword(passwordEncoder.encode(rawPassword));
        u.setRole(role);
        return userRepository.save(u);
    }

    private Property createProperty(String title, String description,
                                    String location, BigDecimal price, User host) {
        Property p = new Property();
        p.setTitle(title);
        p.setDescription(description);
        p.setLocation(location);
        p.setPricePerNight(price);
        p.setHost(host);
        return propertyRepository.save(p);
    }

    private void addAvailability(Property property, LocalDate from, LocalDate to) {
        PropertyAvailability pa = new PropertyAvailability();
        pa.setProperty(property);
        pa.setAvailableFrom(from);
        pa.setAvailableTo(to);
        availabilityRepository.save(pa);
    }

    private Booking createBooking(Property property, User guest,
                                  LocalDate start, LocalDate end,
                                  BigDecimal totalPrice, BookingStatus status) {
        Booking b = new Booking();
        b.setProperty(property);
        b.setGuest(guest);
        b.setStartDate(start);
        b.setEndDate(end);
        b.setTotalPrice(totalPrice);
        b.setStatus(status);
        return bookingRepository.save(b);
    }

    private void createReview(Property property, User guest, int rating, String comment) {
        Review r = new Review();
        r.setProperty(property);
        r.setGuest(guest);
        r.setRating(rating);
        r.setComment(comment);
        reviewRepository.save(r);
    }
}

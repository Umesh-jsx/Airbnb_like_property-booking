package com.airbnb.booking.repository;

import com.airbnb.booking.entity.Property;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PropertyRepository extends JpaRepository<Property, Long> {

    Page<Property> findByLocationContainingIgnoreCase(String location, Pageable pageable);

    @Query("SELECT p FROM Property p WHERE " +
           "LOWER(p.location) LIKE LOWER(CONCAT('%', :location, '%')) " +
           "AND p.pricePerNight BETWEEN :minPrice AND :maxPrice")
    Page<Property> findByLocationAndPriceRange(
            @Param("location") String location,
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice,
            Pageable pageable);

    List<Property> findByHostId(Long hostId);

    @Query("SELECT p FROM Property p LEFT JOIN p.reviews r GROUP BY p ORDER BY AVG(r.rating) DESC NULLS LAST")
    Page<Property> findPopularProperties(Pageable pageable);
}

package com.airbnb.booking.dto.response;

import com.airbnb.booking.entity.Property;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class PropertyResponse {

    private Long id;
    private String title;
    private String description;
    private String location;
    private BigDecimal pricePerNight;
    private Long hostId;
    private String hostName;
    private Double averageRating;
    private int reviewCount;
    private LocalDateTime createdAt;

    public static PropertyResponse from(Property property) {
        PropertyResponse response = new PropertyResponse();
        response.setId(property.getId());
        response.setTitle(property.getTitle());
        response.setDescription(property.getDescription());
        response.setLocation(property.getLocation());
        response.setPricePerNight(property.getPricePerNight());
        response.setHostId(property.getHost().getId());
        response.setHostName(property.getHost().getName());
        response.setReviewCount(property.getReviews().size());
        if (!property.getReviews().isEmpty()) {
            double avg = property.getReviews().stream()
                    .mapToInt(r -> r.getRating())
                    .average()
                    .orElse(0.0);
            response.setAverageRating(Math.round(avg * 10.0) / 10.0);
        }
        response.setCreatedAt(property.getCreatedAt());
        return response;
    }
}

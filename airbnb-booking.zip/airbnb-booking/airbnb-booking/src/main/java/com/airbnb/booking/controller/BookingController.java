package com.airbnb.booking.controller;

import com.airbnb.booking.dto.request.BookingRequest;
import com.airbnb.booking.dto.response.ApiResponse;
import com.airbnb.booking.dto.response.BookingResponse;
import com.airbnb.booking.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Bookings", description = "Booking creation and lifecycle management")
@SecurityRequirement(name = "Bearer Authentication")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    @Operation(summary = "Create a booking request (GUEST only)")
    public ResponseEntity<ApiResponse<BookingResponse>> createBooking(
            @Valid @RequestBody BookingRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        BookingResponse booking = bookingService.createBooking(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Booking request submitted", booking));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get booking history for a specific user")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getUserBookings(@PathVariable Long userId) {
        List<BookingResponse> bookings = bookingService.getUserBookings(userId);
        return ResponseEntity.ok(ApiResponse.success(bookings));
    }

    @GetMapping("/property/{propertyId}")
    @Operation(summary = "Get all bookings for a property (HOST only)")
    public ResponseEntity<ApiResponse<List<BookingResponse>>> getPropertyBookings(
            @PathVariable Long propertyId,
            @AuthenticationPrincipal UserDetails userDetails) {
        List<BookingResponse> bookings = bookingService.getPropertyBookings(propertyId, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success(bookings));
    }

    @PutMapping("/{id}/cancel")
    @Operation(summary = "Cancel a booking (GUEST or HOST)")
    public ResponseEntity<ApiResponse<BookingResponse>> cancelBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        BookingResponse booking = bookingService.cancelBooking(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Booking cancelled", booking));
    }

    @PutMapping("/{id}/confirm")
    @Operation(summary = "Confirm a booking (HOST only)")
    public ResponseEntity<ApiResponse<BookingResponse>> confirmBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        BookingResponse booking = bookingService.confirmBooking(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Booking confirmed", booking));
    }

    @PutMapping("/{id}/complete")
    @Operation(summary = "Mark a booking as completed (HOST only)")
    public ResponseEntity<ApiResponse<BookingResponse>> completeBooking(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        BookingResponse booking = bookingService.completeBooking(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Booking completed", booking));
    }
}

package com.airbnb.booking.enums;

public enum UserRole {
    HOST,
    GUEST
}

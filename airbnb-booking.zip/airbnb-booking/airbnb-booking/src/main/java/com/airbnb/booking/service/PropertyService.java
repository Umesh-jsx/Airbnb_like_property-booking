package com.airbnb.booking.service;

import com.airbnb.booking.dto.request.AvailabilityRequest;
import com.airbnb.booking.dto.request.PropertyRequest;
import com.airbnb.booking.dto.response.BookingStatisticsResponse;
import com.airbnb.booking.dto.response.PropertyResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;

public interface PropertyService {

    PropertyResponse createProperty(PropertyRequest request, String hostEmail);

    PropertyResponse updateProperty(Long propertyId, PropertyRequest request, String hostEmail);

    PropertyResponse getPropertyById(Long propertyId);

    Page<PropertyResponse> searchProperties(String location, BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable);

    void setAvailability(Long propertyId, AvailabilityRequest request, String hostEmail);

    List<PropertyResponse> getPropertiesByHost(Long hostId);

    Page<PropertyResponse> getPopularProperties(Pageable pageable);

    BookingStatisticsResponse getBookingStatistics(Long propertyId, String hostEmail);
}

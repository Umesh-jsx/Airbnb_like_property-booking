package com.airbnb.booking.service;

import com.airbnb.booking.dto.request.BookingRequest;
import com.airbnb.booking.dto.response.BookingResponse;

import java.util.List;

public interface BookingService {

    BookingResponse createBooking(BookingRequest request, String guestEmail);

    List<BookingResponse> getUserBookings(Long userId);

    List<BookingResponse> getPropertyBookings(Long propertyId, String hostEmail);

    BookingResponse cancelBooking(Long bookingId, String userEmail);

    BookingResponse confirmBooking(Long bookingId, String hostEmail);

    BookingResponse completeBooking(Long bookingId, String hostEmail);
}

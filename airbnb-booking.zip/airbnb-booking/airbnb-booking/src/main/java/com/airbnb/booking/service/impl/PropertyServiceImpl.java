package com.airbnb.booking.service.impl;

import com.airbnb.booking.dto.request.AvailabilityRequest;
import com.airbnb.booking.dto.request.PropertyRequest;
import com.airbnb.booking.dto.response.BookingStatisticsResponse;
import com.airbnb.booking.dto.response.PropertyResponse;
import com.airbnb.booking.entity.Property;
import com.airbnb.booking.entity.PropertyAvailability;
import com.airbnb.booking.entity.User;
import com.airbnb.booking.enums.BookingStatus;
import com.airbnb.booking.enums.UserRole;
import com.airbnb.booking.exception.ResourceNotFoundException;
import com.airbnb.booking.exception.UnauthorizedException;
import com.airbnb.booking.repository.BookingRepository;
import com.airbnb.booking.repository.PropertyAvailabilityRepository;
import com.airbnb.booking.repository.PropertyRepository;
import com.airbnb.booking.repository.ReviewRepository;
import com.airbnb.booking.repository.UserRepository;
import com.airbnb.booking.service.PropertyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PropertyServiceImpl implements PropertyService {

    private static final Logger log = LoggerFactory.getLogger(PropertyServiceImpl.class);

    private final PropertyRepository propertyRepository;
    private final PropertyAvailabilityRepository availabilityRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final ReviewRepository reviewRepository;

    public PropertyServiceImpl(PropertyRepository propertyRepository,
                               PropertyAvailabilityRepository availabilityRepository,
                               UserRepository userRepository,
                               BookingRepository bookingRepository,
                               ReviewRepository reviewRepository) {
        this.propertyRepository = propertyRepository;
        this.availabilityRepository = availabilityRepository;
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
        this.reviewRepository = reviewRepository;
    }

    @Override
    @Transactional
    public PropertyResponse createProperty(PropertyRequest request, String hostEmail) {
        User host = getUserByEmail(hostEmail);
        validateHostRole(host);

        Property property = new Property();
        property.setTitle(request.getTitle());
        property.setDescription(request.getDescription());
        property.setLocation(request.getLocation());
        property.setPricePerNight(request.getPricePerNight());
        property.setHost(host);

        Property saved = propertyRepository.save(property);
        log.info("Property created: {} by host: {}", saved.getId(), hostEmail);
        return PropertyResponse.from(saved);
    }

    @Override
    @Transactional
    public PropertyResponse updateProperty(Long propertyId, PropertyRequest request, String hostEmail) {
        Property property = getPropertyEntity(propertyId);
        validatePropertyOwner(property, hostEmail);

        property.setTitle(request.getTitle());
        property.setDescription(request.getDescription());
        property.setLocation(request.getLocation());
        property.setPricePerNight(request.getPricePerNight());

        Property saved = propertyRepository.save(property);
        log.info("Property updated: {}", propertyId);
        return PropertyResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public PropertyResponse getPropertyById(Long propertyId) {
        Property property = getPropertyEntity(propertyId);
        return PropertyResponse.from(property);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PropertyResponse> searchProperties(String location, BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable) {
        Page<Property> properties;
        if (minPrice != null && maxPrice != null) {
            properties = propertyRepository.findByLocationAndPriceRange(location, minPrice, maxPrice, pageable);
        } else {
            properties = propertyRepository.findByLocationContainingIgnoreCase(location, pageable);
        }
        return properties.map(PropertyResponse::from);
    }

    @Override
    @Transactional
    public void setAvailability(Long propertyId, AvailabilityRequest request, String hostEmail) {
        Property property = getPropertyEntity(propertyId);
        validatePropertyOwner(property, hostEmail);

        if (request.getAvailableTo().isBefore(request.getAvailableFrom())) {
            throw new IllegalArgumentException("Available-to date must be after available-from date");
        }

        PropertyAvailability availability = new PropertyAvailability();
        availability.setProperty(property);
        availability.setAvailableFrom(request.getAvailableFrom());
        availability.setAvailableTo(request.getAvailableTo());
        availabilityRepository.save(availability);
        log.info("Availability set for property: {} [{} to {}]",
                propertyId, request.getAvailableFrom(), request.getAvailableTo());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PropertyResponse> getPropertiesByHost(Long hostId) {
        userRepository.findById(hostId)
                .orElseThrow(() -> new ResourceNotFoundException("User", hostId));
        return propertyRepository.findByHostId(hostId)
                .stream().map(PropertyResponse::from).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PropertyResponse> getPopularProperties(Pageable pageable) {
        return propertyRepository.findPopularProperties(pageable).map(PropertyResponse::from);
    }

    @Override
    @Transactional(readOnly = true)
    public BookingStatisticsResponse getBookingStatistics(Long propertyId, String hostEmail) {
        Property property = getPropertyEntity(propertyId);
        validatePropertyOwner(property, hostEmail);

        BookingStatisticsResponse stats = new BookingStatisticsResponse();
        stats.setPropertyId(propertyId);
        stats.setPropertyTitle(property.getTitle());

        List<Object[]> counts = bookingRepository.countBookingsByStatusForProperty(propertyId);
        long total = 0;
        for (Object[] row : counts) {
            BookingStatus status = (BookingStatus) row[0];
            long count = (Long) row[1];
            total += count;
            switch (status) {
                case REQUESTED -> stats.setRequestedBookings(count);
                case CONFIRMED -> stats.setConfirmedBookings(count);
                case CANCELLED -> stats.setCancelledBookings(count);
                case COMPLETED -> stats.setCompletedBookings(count);
            }
        }
        stats.setTotalBookings(total);

        Double avgRating = reviewRepository.findAverageRatingByPropertyId(propertyId);
        stats.setAverageRating(avgRating != null ? Math.round(avgRating * 10.0) / 10.0 : null);
        stats.setTotalReviews(property.getReviews().size());

        return stats;
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private Property getPropertyEntity(Long propertyId) {
        return propertyRepository.findById(propertyId)
                .orElseThrow(() -> new ResourceNotFoundException("Property", propertyId));
    }

    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    private void validateHostRole(User user) {
        if (user.getRole() != UserRole.HOST) {
            throw new UnauthorizedException("Only hosts can manage properties");
        }
    }

    private void validatePropertyOwner(Property property, String email) {
        if (!property.getHost().getEmail().equals(email)) {
            throw new UnauthorizedException("You do not own this property");
        }
    }
}

package com.airbnb.booking.controller;

import com.airbnb.booking.dto.request.AvailabilityRequest;
import com.airbnb.booking.dto.request.PropertyRequest;
import com.airbnb.booking.dto.response.ApiResponse;
import com.airbnb.booking.dto.response.BookingStatisticsResponse;
import com.airbnb.booking.dto.response.PropertyResponse;
import com.airbnb.booking.service.PropertyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/properties")
@Tag(name = "Properties", description = "Property listing and management")
public class PropertyController {

    private final PropertyService propertyService;

    public PropertyController(PropertyService propertyService) {
        this.propertyService = propertyService;
    }

    @PostMapping
    @Operation(summary = "Create a new property listing (HOST only)", security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<PropertyResponse>> createProperty(
            @Valid @RequestBody PropertyRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        PropertyResponse property = propertyService.createProperty(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Property created successfully", property));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update property details (HOST only)", security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<PropertyResponse>> updateProperty(
            @PathVariable Long id,
            @Valid @RequestBody PropertyRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        PropertyResponse property = propertyService.updateProperty(id, request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Property updated successfully", property));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get property details by ID")
    public ResponseEntity<ApiResponse<PropertyResponse>> getProperty(@PathVariable Long id) {
        PropertyResponse property = propertyService.getPropertyById(id);
        return ResponseEntity.ok(ApiResponse.success(property));
    }

    @GetMapping
    @Operation(summary = "Search properties by location and optional price range (paginated)")
    public ResponseEntity<ApiResponse<Page<PropertyResponse>>> searchProperties(
            @RequestParam(defaultValue = "") String location,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @PageableDefault(size = 10) Pageable pageable) {
        Page<PropertyResponse> properties = propertyService.searchProperties(location, minPrice, maxPrice, pageable);
        return ResponseEntity.ok(ApiResponse.success(properties));
    }

    @PostMapping("/{id}/availability")
    @Operation(summary = "Set availability dates for a property (HOST only)", security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<Void>> setAvailability(
            @PathVariable Long id,
            @Valid @RequestBody AvailabilityRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        propertyService.setAvailability(id, request, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Availability set successfully", null));
    }

    @GetMapping("/host/{hostId}")
    @Operation(summary = "Get all properties listed by a specific host")
    public ResponseEntity<ApiResponse<List<PropertyResponse>>> getPropertiesByHost(@PathVariable Long hostId) {
        List<PropertyResponse> properties = propertyService.getPropertiesByHost(hostId);
        return ResponseEntity.ok(ApiResponse.success(properties));
    }

    @GetMapping("/popular")
    @Operation(summary = "Get popular properties sorted by average rating (paginated)")
    public ResponseEntity<ApiResponse<Page<PropertyResponse>>> getPopularProperties(
            @PageableDefault(size = 10) Pageable pageable) {
        Page<PropertyResponse> properties = propertyService.getPopularProperties(pageable);
        return ResponseEntity.ok(ApiResponse.success(properties));
    }

    @GetMapping("/{id}/statistics")
    @Operation(summary = "Get booking statistics for a property (HOST only)", security = @SecurityRequirement(name = "Bearer Authentication"))
    public ResponseEntity<ApiResponse<BookingStatisticsResponse>> getStatistics(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {
        BookingStatisticsResponse stats = propertyService.getBookingStatistics(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}

package com.airbnb.booking.repository;

import com.airbnb.booking.entity.Booking;
import com.airbnb.booking.enums.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByGuestId(Long guestId);

    List<Booking> findByPropertyId(Long propertyId);

    // Check for overlapping bookings – prevents double-booking
    @Query("SELECT COUNT(b) > 0 FROM Booking b WHERE b.property.id = :propertyId " +
           "AND b.status IN ('REQUESTED', 'CONFIRMED') " +
           "AND b.startDate < :endDate AND b.endDate > :startDate")
    boolean hasOverlappingBooking(
            @Param("propertyId") Long propertyId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);

    // Count bookings grouped by status for a property
    @Query("SELECT b.status, COUNT(b) FROM Booking b WHERE b.property.id = :propertyId GROUP BY b.status")
    List<Object[]> countBookingsByStatusForProperty(@Param("propertyId") Long propertyId);

    // Completed bookings for guest on a property (used for review eligibility)
    @Query("SELECT COUNT(b) > 0 FROM Booking b WHERE b.property.id = :propertyId " +
           "AND b.guest.id = :guestId AND b.status = 'COMPLETED'")
    boolean hasCompletedBooking(
            @Param("propertyId") Long propertyId,
            @Param("guestId") Long guestId);

    List<Booking> findByPropertyIdAndStatus(Long propertyId, BookingStatus status);
}

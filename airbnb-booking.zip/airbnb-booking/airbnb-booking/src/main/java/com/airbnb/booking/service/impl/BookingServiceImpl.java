package com.airbnb.booking.service.impl;

import com.airbnb.booking.dto.request.BookingRequest;
import com.airbnb.booking.dto.response.BookingResponse;
import com.airbnb.booking.entity.Booking;
import com.airbnb.booking.entity.Property;
import com.airbnb.booking.entity.User;
import com.airbnb.booking.enums.BookingStatus;
import com.airbnb.booking.enums.UserRole;
import com.airbnb.booking.exception.BookingConflictException;
import com.airbnb.booking.exception.ResourceNotFoundException;
import com.airbnb.booking.exception.UnauthorizedException;
import com.airbnb.booking.repository.BookingRepository;
import com.airbnb.booking.repository.PropertyAvailabilityRepository;
import com.airbnb.booking.repository.PropertyRepository;
import com.airbnb.booking.repository.UserRepository;
import com.airbnb.booking.service.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingServiceImpl implements BookingService {

    private static final Logger log = LoggerFactory.getLogger(BookingServiceImpl.class);

    private final BookingRepository bookingRepository;
    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final PropertyAvailabilityRepository availabilityRepository;

    public BookingServiceImpl(BookingRepository bookingRepository,
                              PropertyRepository propertyRepository,
                              UserRepository userRepository,
                              PropertyAvailabilityRepository availabilityRepository) {
        this.bookingRepository = bookingRepository;
        this.propertyRepository = propertyRepository;
        this.userRepository = userRepository;
        this.availabilityRepository = availabilityRepository;
    }

    @Override
    @Transactional
    public BookingResponse createBooking(BookingRequest request, String guestEmail) {
        // Validate dates
        if (!request.getEndDate().isAfter(request.getStartDate())) {
            throw new IllegalArgumentException("End date must be after start date");
        }

        User guest = getUserByEmail(guestEmail);
        if (guest.getRole() != UserRole.GUEST) {
            throw new UnauthorizedException("Only guests can create bookings");
        }

        Property property = propertyRepository.findById(request.getPropertyId())
                .orElseThrow(() -> new ResourceNotFoundException("Property", request.getPropertyId()));

        // Prevent guest from booking their own property (if they are also a host)
        if (property.getHost().getEmail().equals(guestEmail)) {
            throw new UnauthorizedException("You cannot book your own property");
        }

        // Check property availability window
        boolean withinAvailability = availabilityRepository.isPropertyAvailableForDates(
                property.getId(), request.getStartDate(), request.getEndDate());
        if (!withinAvailability) {
            throw new BookingConflictException(
                    "Property is not available for the selected dates. Please check the availability calendar.");
        }

        // Prevent overlapping/double booking
        boolean hasConflict = bookingRepository.hasOverlappingBooking(
                property.getId(), request.getStartDate(), request.getEndDate());
        if (hasConflict) {
            throw new BookingConflictException(
                    "Property is already booked for the selected dates. Please choose different dates.");
        }

        // Calculate total price
        long nights = ChronoUnit.DAYS.between(request.getStartDate(), request.getEndDate());
        BigDecimal totalPrice = property.getPricePerNight().multiply(BigDecimal.valueOf(nights));

        Booking booking = new Booking();
        booking.setProperty(property);
        booking.setGuest(guest);
        booking.setStartDate(request.getStartDate());
        booking.setEndDate(request.getEndDate());
        booking.setTotalPrice(totalPrice);
        booking.setStatus(BookingStatus.REQUESTED);

        Booking saved = bookingRepository.save(booking);
        log.info("Booking created: {} for property: {} by guest: {}", saved.getId(), property.getId(), guestEmail);
        return BookingResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookingResponse> getUserBookings(Long userId) {
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", userId));
        return bookingRepository.findByGuestId(userId)
                .stream().map(BookingResponse::from).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<BookingResponse> getPropertyBookings(Long propertyId, String hostEmail) {
        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new ResourceNotFoundException("Property", propertyId));
        if (!property.getHost().getEmail().equals(hostEmail)) {
            throw new UnauthorizedException("You do not own this property");
        }
        return bookingRepository.findByPropertyId(propertyId)
                .stream().map(BookingResponse::from).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public BookingResponse cancelBooking(Long bookingId, String userEmail) {
        Booking booking = getBookingEntity(bookingId);
        boolean isGuest = booking.getGuest().getEmail().equals(userEmail);
        boolean isHost = booking.getProperty().getHost().getEmail().equals(userEmail);

        if (!isGuest && !isHost) {
            throw new UnauthorizedException("You are not authorized to cancel this booking");
        }
        if (booking.getStatus() == BookingStatus.COMPLETED) {
            throw new IllegalArgumentException("Completed bookings cannot be cancelled");
        }
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new IllegalArgumentException("Booking is already cancelled");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        Booking saved = bookingRepository.save(booking);
        log.info("Booking cancelled: {} by: {}", bookingId, userEmail);
        return BookingResponse.from(saved);
    }

    @Override
    @Transactional
    public BookingResponse confirmBooking(Long bookingId, String hostEmail) {
        Booking booking = getBookingEntity(bookingId);
        validateHostOwnsBooking(booking, hostEmail);

        if (booking.getStatus() != BookingStatus.REQUESTED) {
            throw new IllegalArgumentException("Only REQUESTED bookings can be confirmed");
        }

        booking.setStatus(BookingStatus.CONFIRMED);
        Booking saved = bookingRepository.save(booking);
        log.info("Booking confirmed: {}", bookingId);
        return BookingResponse.from(saved);
    }

    @Override
    @Transactional
    public BookingResponse completeBooking(Long bookingId, String hostEmail) {
        Booking booking = getBookingEntity(bookingId);
        validateHostOwnsBooking(booking, hostEmail);

        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw new IllegalArgumentException("Only CONFIRMED bookings can be completed");
        }

        booking.setStatus(BookingStatus.COMPLETED);
        Booking saved = bookingRepository.save(booking);
        log.info("Booking completed: {}", bookingId);
        return BookingResponse.from(saved);
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private Booking getBookingEntity(Long bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking", bookingId));
    }

    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    private void validateHostOwnsBooking(Booking booking, String hostEmail) {
        if (!booking.getProperty().getHost().getEmail().equals(hostEmail)) {
            throw new UnauthorizedException("You do not own the property for this booking");
        }
    }
}

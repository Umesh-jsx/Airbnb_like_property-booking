package com.airbnb.booking.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookingStatisticsResponse {

    private Long propertyId;
    private String propertyTitle;
    private long totalBookings;
    private long requestedBookings;
    private long confirmedBookings;
    private long cancelledBookings;
    private long completedBookings;
    private Double averageRating;
    private int totalReviews;
}

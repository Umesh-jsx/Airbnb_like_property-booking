package com.airbnb.booking.dto.response;

import com.airbnb.booking.entity.Booking;
import com.airbnb.booking.enums.BookingStatus;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Getter
@Setter
public class BookingResponse {

    private Long id;
    private Long propertyId;
    private String propertyTitle;
    private String propertyLocation;
    private Long guestId;
    private String guestName;
    private LocalDate startDate;
    private LocalDate endDate;
    private long numberOfNights;
    private BigDecimal totalPrice;
    private BookingStatus status;
    private LocalDateTime createdAt;

    public static BookingResponse from(Booking booking) {
        BookingResponse response = new BookingResponse();
        response.setId(booking.getId());
        response.setPropertyId(booking.getProperty().getId());
        response.setPropertyTitle(booking.getProperty().getTitle());
        response.setPropertyLocation(booking.getProperty().getLocation());
        response.setGuestId(booking.getGuest().getId());
        response.setGuestName(booking.getGuest().getName());
        response.setStartDate(booking.getStartDate());
        response.setEndDate(booking.getEndDate());
        response.setNumberOfNights(ChronoUnit.DAYS.between(booking.getStartDate(), booking.getEndDate()));
        response.setTotalPrice(booking.getTotalPrice());
        response.setStatus(booking.getStatus());
        response.setCreatedAt(booking.getCreatedAt());
        return response;
    }
}
